"""ЗАГЛУШКА сервиса расписания (у организаторов API нет — описываем контракт и имитируем).

Контракт, который мы ожидаем от МИС (1С):
  GET /schedule/slots?specialty=<route_key>&from=<ISO>&limit=4
  -> [{"slot_id": "...", "start": "ISO", "branch": "Текстильщики", "doctor": "...", "online": false}]
  POST /schedule/book {"slot_id": "...", "patient": "<псевдо-ID>"} -> {"ok": true}

Ссылка в сообщении пациенту должна вести СРАЗУ на эти слоты нужного профиля — пациент не ищет врача сам.
"""
from datetime import timedelta                     # сдвиги по времени
from app import store                              # модельное время

BRANCHES = ["Текстильщики", "Сенежская", "ВДНХ"]   # филиалы (пример из ТЗ)


def slots(route_key: str, limit: int = 4) -> list:
    """Ближайшие слоты для профиля. Генерируются от модельного «сейчас»."""
    base = store.now().replace(minute=0, second=0)   # округляем до часа
    plan = [                                       # (через сколько часов, филиал или онлайн)
        (3, None),                                 # сегодня онлайн
        (18, BRANCHES[0]),                         # завтра утром — Текстильщики
        (26, BRANCHES[1]),                         # завтра вечером — Сенежская
        (45, None),                                # послезавтра онлайн
    ]
    out = []                                       # результат
    for i, (h, br) in enumerate(plan[:limit]):     # каждый слот
        t = base + timedelta(hours=h)              # время слота
        out.append({                               # описание слота
            "slot_id": f"{route_key}-{t:%Y%m%d%H}-{i}",   # уникальный ID слота
            "start": t.isoformat(),                # время начала
            "branch": br or "Онлайн",              # филиал
            "online": br is None,                  # онлайн-консультация?
            "label": f"{t:%d.%m %H:%M} — {br or 'онлайн'}",   # подпись для кнопки
        })
    return out                                     # список слотов
