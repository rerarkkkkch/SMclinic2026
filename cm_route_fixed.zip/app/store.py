"""Хранилище: локальная SQLite-база (один файл). Ничего не уходит наружу.

Таблицы:
  protocols     — протоколы (обезличенный текст + результат извлечения)
  routes        — маршруты пациентов (один маршрут = один профильный специалист)
  events        — ID обработанных событий МИС (идемпотентность)
  notifications — все «отправленные» сообщения (заглушка)
  audit         — журнал: кто, что, когда и на каком основании
  feedback      — отметки админа «ложное» / «пропущено»
  settings      — служебное, в т.ч. модельное время (только демо)
"""
import json                                        # хранение сложных полей как JSON
import os                                          # пути
import sqlite3                                     # встроенная база данных
import threading                                   # блокировка для многопоточного веб-сервера
from contextlib import contextmanager              # FIX: транзакция «всё или ничего» для обработки события
from datetime import datetime, timedelta           # время
from app.config import BASE_DIR                    # корень проекта

DB_PATH = os.environ.get("CM_DB", os.path.join(BASE_DIR, "data", "cm_route.db"))   # путь к файлу базы
# FIX: модельное время — только для демо. В бою часы реальные, иначе напоминания никогда не наступят
MODEL_CLOCK = os.environ.get("CM_ENV", "production") == "demo"
_lock = threading.RLock()                          # одна блокировка на запись (в пределах ОДНОГО процесса — запускать с 1 воркером)
_local = threading.local()                         # FIX: соединение текущей транзакции (для вложенных вызовов)

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS protocols (id TEXT PRIMARY KEY NOT NULL, patient TEXT NOT NULL, study TEXT, study_date TEXT, text TEXT,
    version INTEGER, status TEXT, extraction TEXT, created_at TEXT, updated_at TEXT);
CREATE TABLE IF NOT EXISTS routes (id INTEGER PRIMARY KEY AUTOINCREMENT, protocol_id TEXT NOT NULL, patient TEXT NOT NULL, route_key TEXT NOT NULL,
    status TEXT NOT NULL, findings TEXT, verification TEXT, priority INTEGER, urgent INTEGER, due_date TEXT, created_at TEXT,
    notified_at TEXT, ladder_start TEXT, ladder_step INTEGER DEFAULT 0, booked_slot TEXT, updated_at TEXT,
    acked_by TEXT, acked_at TEXT, last_escalation TEXT);
CREATE TABLE IF NOT EXISTS events (event_id TEXT PRIMARY KEY, received_at TEXT);
CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, channel TEXT, recipient TEXT,
    text TEXT, route_id INTEGER, status TEXT, kind TEXT, batch TEXT);
CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, actor TEXT, action TEXT, route_id INTEGER,
    protocol_id TEXT, details TEXT);
CREATE TABLE IF NOT EXISTS feedback (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, protocol_id TEXT, finding_id TEXT,
    kind TEXT, quote TEXT, comment TEXT);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
-- FIX: индексов не было — очередь, баннер и планировщик делали полный перебор таблиц
CREATE INDEX IF NOT EXISTS ix_routes_protocol ON routes(protocol_id);
CREATE INDEX IF NOT EXISTS ix_routes_patient ON routes(patient);
CREATE INDEX IF NOT EXISTS ix_routes_status ON routes(status);
CREATE INDEX IF NOT EXISTS ix_notif_sched ON notifications(status, ts);
CREATE INDEX IF NOT EXISTS ix_notif_route ON notifications(route_id);
CREATE INDEX IF NOT EXISTS ix_audit_route ON audit(route_id);
"""


def _connect():
    """Новое соединение (строки как словари, ожидание блокировки до 10 с вместо мгновенной ошибки)."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)   # папка базы
    c = sqlite3.connect(DB_PATH, timeout=10)       # FIX: timeout — фоновые потоки и веб не падают с "database is locked"
    c.row_factory = sqlite3.Row                    # строки как словари
    return c


@contextmanager
def tx():
    """FIX: одна транзакция на всю обработку события. Ошибка в середине -> откат всего,
    включая отметку event_id, поэтому повторная доставка от МИС снова обработает событие."""
    if getattr(_local, "conn", None) is not None:  # уже внутри транзакции — просто участвуем в ней
        yield _local.conn
        return
    with _lock:                                    # сериализуем запись внутри процесса
        c = _connect()
        _local.conn = c                            # все store.q/x в этом потоке пойдут через это соединение
        try:
            c.execute("BEGIN IMMEDIATE")           # сразу берём блокировку записи
            yield c
            c.commit()                             # всё прошло — фиксируем
        except BaseException:
            c.rollback()                           # любая ошибка — откат целиком
            raise
        finally:
            _local.conn = None
            c.close()                              # FIX: раньше соединения не закрывались явно


def _run(sql, args, fetch):
    c = getattr(_local, "conn", None)              # внутри транзакции?
    if c is not None:
        cur = c.execute(sql, args)
        return [dict(r) for r in cur.fetchall()] if fetch else cur.lastrowid
    with _lock if not fetch else _nolock():        # одиночная запись — под блокировкой
        c = _connect()
        try:
            cur = c.execute(sql, args)
            out = [dict(r) for r in cur.fetchall()] if fetch else cur.lastrowid
            c.commit()
            return out
        finally:
            c.close()


@contextmanager
def _nolock():
    yield


def init():
    """Создать таблицы и индексы, если их ещё нет."""
    with _lock:
        c = _connect()
        try:
            c.executescript(SCHEMA)
            for col in ("acked_by TEXT", "acked_at TEXT", "last_escalation TEXT"):   # миграция старых баз
                try:
                    c.execute(f"ALTER TABLE routes ADD COLUMN {col}")
                except sqlite3.OperationalError:
                    pass                           # колонка уже есть
            try:
                c.execute("ALTER TABLE notifications ADD COLUMN batch TEXT")
            except sqlite3.OperationalError:
                pass
            c.commit()
        finally:
            c.close()


def reset():
    """Полностью очистить базу (ТОЛЬКО демо — эндпоинт закрыт в бою)."""
    with _lock:
        for suffix in ("", "-wal", "-shm"):        # WAL-файлы тоже
            if os.path.exists(DB_PATH + suffix):
                os.remove(DB_PATH + suffix)
        init()


def q(sql, args=()):
    """SELECT -> список словарей."""
    return _run(sql, args, True)


def x(sql, args=()):
    """INSERT/UPDATE/DELETE -> ID вставленной строки."""
    return _run(sql, args, False)


def claim_event(event_id: str) -> bool:
    """FIX: атомарно «занять» event_id. Было: SELECT, затем INSERT — два одновременных
    запроса оба проходили проверку. Теперь INSERT OR IGNORE: ровно один получит True.
    Вызывать ВНУТРИ tx(), чтобы при ошибке отметка откатилась."""
    c = getattr(_local, "conn", None)
    assert c is not None, "claim_event вызывается только внутри store.tx()"
    cur = c.execute("INSERT OR IGNORE INTO events VALUES (?,?)", (event_id, ts()))
    return cur.rowcount == 1


# ------------------------- Время -------------------------
def now() -> datetime:
    """Текущее время. В бою — реальные часы; в демо — модельные (сдвигаются кнопками)."""
    if not MODEL_CLOCK:
        return datetime.now().replace(microsecond=0)
    r = q("SELECT value FROM settings WHERE key='clock'")
    if r:
        return datetime.fromisoformat(r[0]["value"])
    t = datetime.now().replace(microsecond=0)
    # FIX: INSERT OR IGNORE — при одновременном первом запросе раньше 6 из 8 падали с IntegrityError
    x("INSERT OR IGNORE INTO settings VALUES ('clock', ?)", (t.isoformat(),))
    return datetime.fromisoformat(q("SELECT value FROM settings WHERE key='clock'")[0]["value"])


def advance(hours: float) -> datetime:
    """Сдвинуть модельное время (только демо)."""
    if not MODEL_CLOCK:
        raise RuntimeError("модельное время доступно только при CM_ENV=demo")
    t = now() + timedelta(hours=hours)
    x("UPDATE settings SET value=? WHERE key='clock'", (t.isoformat(),))
    return t


def ts() -> str:
    """Время строкой (ISO) для записи в таблицы."""
    return now().isoformat()


# ------------------------- Журнал -------------------------
def audit(actor, action, route_id=None, protocol_id=None, **details):
    """Записать действие в журнал."""
    x("INSERT INTO audit (ts, actor, action, route_id, protocol_id, details) VALUES (?,?,?,?,?,?)",
      (ts(), actor, action, route_id, protocol_id, json.dumps(details, ensure_ascii=False)))


# ------------------------- Удобные выборки -------------------------
def route(rid: int) -> dict:
    """Один маршрут (JSON-поля разобраны) или None."""
    r = q("SELECT * FROM routes WHERE id=?", (rid,))
    if not r:
        return None
    r = r[0]
    r["findings"] = json.loads(r["findings"] or "[]")
    return r


_ROUTE_COLS = {"status", "findings", "verification", "priority", "urgent", "due_date", "notified_at", "ladder_start",
               "ladder_step", "booked_slot", "acked_by", "acked_at", "last_escalation"}


def update_route(rid: int, **fields):
    """Обновить поля маршрута. FIX: белый список колонок — имена полей подставляются в SQL строкой."""
    bad = set(fields) - _ROUTE_COLS
    if bad:
        raise ValueError(f"недопустимые поля маршрута: {bad}")
    fields["updated_at"] = ts()
    cols = ", ".join(f"{k}=?" for k in fields)
    x(f"UPDATE routes SET {cols} WHERE id=?", (*fields.values(), rid))
