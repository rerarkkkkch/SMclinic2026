"""ВЕБ-СЕРВИС (FastAPI). Запуск: uvicorn app.main:app --port 8000  ->  http://localhost:8000

Что здесь есть:
  POST /api/events            — вебхук для МИС (1С): протокол подписан/исправлен/аннулирован, события записи
  POST /api/upload            — загрузить PDF/TXT протокола вручную (для демо)
  data/inbox/                 — «автоматическая загрузка»: положите файл в папку — он обработается сам
  POST /api/analyze           — песочница: показать, что найдёт система в тексте (без создания маршрута)
  GET  /api/routes            — очередь маршрутов для админа
  GET  /api/routes/{id}       — карточка: текст с подсветкой, находки, правила, журнал, сообщения
  POST /api/routes/{id}/action — подтвердить / отклонить / записать / приём / неявка ...
  POST /api/clock/advance     — модельное время (+24 ч, +7 дней) и запуск напоминаний
  GET  /api/dashboard         — воронка и экономика
"""
import hashlib                                              # FIX: event_id файла = хэш содержимого (повторный файл не дублируется)
import hmac                                                 # сравнение токенов за постоянное время
import io                                                   # чтение загруженного файла из памяти
import json                                                 # JSON-поля
import os                                                   # пути
import shutil                                               # перемещение файлов из inbox
import threading                                            # фоновый поток для папки inbox
import time                                                 # пауза между проверками папки
import uuid                                                 # генерация ID событий
from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, UploadFile   # веб-фреймворк
from fastapi.responses import FileResponse, PlainTextResponse        # ответы: файл, текст
from pydantic import BaseModel                              # описание входных данных
from app import analytics, config, routing, schedule_mock, store     # модули проекта
from app.config import BASE_DIR                             # корень проекта
from app.nlp.extractor import extract                       # извлечение находок
from app.nlp.ml_layer import get_ml_hook                    # необязательная модель

DEMO = os.environ.get("CM_ENV", "production") == "demo"    # FIX: демо-функции только в демо-режиме
API_TOKEN = os.environ.get("CM_API_TOKEN", "")              # FIX: токен для админки/API
MIS_TOKEN = os.environ.get("CM_MIS_TOKEN", "")              # FIX: отдельный токен для вебхука МИС
MAX_UPLOAD = 10 * 1024 * 1024                               # FIX: лимит загрузки 10 МБ (раньше — без лимита, весь файл в память)
if not DEMO and (len(API_TOKEN) < 32 or len(MIS_TOKEN) < 32):
    raise RuntimeError("В бою нужны CM_API_TOKEN и CM_MIS_TOKEN (≥32 символов). Для демо: CM_ENV=demo")


def _check(token: str, expected: str):
    if DEMO and not expected:                               # демо без токена — разрешаем (только синтетика!)
        return
    if not token or not hmac.compare_digest(token, f"Bearer {expected}"):
        raise HTTPException(401, "Нужна авторизация")


def admin_auth(authorization: str = Header(None)):
    """FIX: раньше ни один эндпоинт не требовал авторизации — включая выгрузку, сброс БД и баннер с находками."""
    _check(authorization, API_TOKEN)


def mis_auth(authorization: str = Header(None)):
    _check(authorization, MIS_TOKEN)


def demo_only():
    if not DEMO:
        raise HTTPException(404, "Недоступно в рабочем режиме")


app = FastAPI(title="CM Route — не потерять пациента (прототип)",
              docs_url="/docs" if DEMO else None, redoc_url=None, openapi_url="/openapi.json" if DEMO else None)
INBOX = os.path.join(BASE_DIR, "data", "inbox")             # папка автозагрузки
STATIC = os.path.join(BASE_DIR, "static")                   # папка интерфейса


# ------------------------------ Входные модели ------------------------------
class Event(BaseModel):
    """Событие от МИС. Формат описан в README (раздел «Контракт событий»)."""
    event_id: str | None = None                             # уникальный ID события (для защиты от дублей)
    type: str                                               # protocol.signed | protocol.corrected | protocol.cancelled | appointment.* | patient.visit
    protocol_id: str | None = None                          # ID протокола в МИС
    patient_id: str | None = None                           # ID пациента в МИС (у нас превратится в псевдо-ID)
    study_type: str | None = None                           # тип исследования («УЗИ органов малого таза»)
    study_date: str | None = None                           # дата исследования
    text: str | None = None                                 # текст протокола
    specialty: str | None = None                            # для appointment.*: ключ маршрута (gyn_surgeon ...)
    route_id: int | None = None                             # для appointment.*: ID маршрута, если МИС его знает
    slot: str | None = None                                 # для appointment.booked: время/место


class Action(BaseModel):
    """Действие по маршруту из интерфейса."""
    action: str                                             # verify | reject | book | cancel | no_show | visit | external | decline
    actor: str = "admin"                                    # кто нажал: admin / patient
    slot: str | None = None                                 # выбранный слот (для book)
    comment: str = ""                                       # комментарий (например, почему ложное)


class TextIn(BaseModel):
    """Текст для песочницы."""
    text: str                                               # произвольный текст протокола


class Missed(BaseModel):
    """Админ отмечает пропущенную находку (ложноотрицательный случай)."""
    protocol_id: str                                        # протокол
    finding_id: str                                         # какая находка пропущена
    quote: str = ""                                         # фрагмент текста
    comment: str = ""                                       # комментарий


# ------------------------------ Служебное ------------------------------
@app.on_event("startup")   # выполнить при запуске сервера
def startup():
    """При старте: создать таблицы и запустить наблюдение за папкой inbox."""
    store.init()                                            # таблицы
    health()                                                # FIX: битый/пустой конфиг — не стартуем
    os.makedirs(os.path.join(INBOX, "processed"), exist_ok=True)   # папки автозагрузки
    threading.Thread(target=_watch_inbox, daemon=True).start()     # фоновый поток
    if not DEMO:                                            # FIX: напоминания по реальным часам (в демо — кнопками)
        threading.Thread(target=_scheduler, daemon=True).start()


def _scheduler():
    """FIX: раньше routing.tick() вызывался только из /api/clock/advance — в бою напоминания не шли никогда."""
    while True:
        try:
            routing.tick()
        except Exception as e:
            print("[scheduler] ошибка:", repr(e), flush=True)
        time.sleep(60)


def _pdf_text(data: bytes) -> str:
    """Текст из PDF (текстовый слой). Сканы потребуют OCR — см. README."""
    import pdfplumber                                       # локальная библиотека чтения PDF
    with pdfplumber.open(io.BytesIO(data)) as pdf:          # открываем PDF из памяти
        text = "\n".join(page.extract_text() or "" for page in pdf.pages)   # текст всех страниц
    if not text.strip():                                    # текста нет — это скан
        raise HTTPException(422, "В PDF нет текстового слоя (скан). Нужен OCR (Tesseract, локально) — заглушка.")   # сообщаем
    return text                                             # текст


def _ingest_file(name: str, data: bytes, patient_id: str = None, study_type: str = None) -> dict:
    """Превратить файл в событие protocol.signed и обработать."""
    text = _pdf_text(data) if name.lower().endswith(".pdf") else data.decode("utf-8")   # FIX: без errors="ignore" — битая кодировка не «съедает» текст молча
    stem = os.path.splitext(os.path.basename(name))[0]      # имя без расширения
    return routing.handle_event({                           # обычное событие, как будто от МИС
        "event_id": "file-" + hashlib.sha256(data).hexdigest(),   # FIX: тот же файл повторно = дубль, а не новая версия протокола
        "type": "protocol.signed",                          # протокол подписан
        "protocol_id": stem,                                # ID протокола = имя файла
        "patient_id": patient_id or stem.split("__")[0],    # ID пациента: из формы или из имени «ПАЦИЕНТ__что-угодно.pdf»
        "study_type": study_type or "Исследование (файл)",  # тип исследования
        "text": text,                                       # текст
    })


def _watch_inbox():
    """«Файл загружается автоматически»: каждые 3 секунды забираем новые файлы из data/inbox.
    FIX 1: try был вокруг ВСЕГО цикла — один скан без текста ронял проход, и все файлы после него
           по алфавиту не обрабатывались никогда (а сам скан повторялся каждые 3 секунды).
    FIX 2: файл берём, только если его размер не менялся между проходами (иначе читали недокопированный PDF).
    FIX 3: ошибочный файл уходит в failed/ и становится задачей админу, а не строкой в консоли."""
    for sub in ("processed", "failed"):
        os.makedirs(os.path.join(INBOX, sub), exist_ok=True)
    sizes = {}
    while True:
        try:
            names = sorted(os.listdir(INBOX))
        except OSError as e:
            print("[inbox] папка недоступна:", repr(e), flush=True)
            names = []
        for fn in names:
            p = os.path.join(INBOX, fn)
            if not (os.path.isfile(p) and fn.lower().endswith((".pdf", ".txt"))):
                continue
            size = os.path.getsize(p)
            if sizes.get(fn) != size:                   # файл ещё копируется — ждём следующего прохода
                sizes[fn] = size
                continue
            sizes.pop(fn, None)
            try:
                with open(p, "rb") as f:
                    _ingest_file(fn, f.read())
                shutil.move(p, os.path.join(INBOX, "processed", fn))
            except Exception as e:
                detail = e.detail if isinstance(e, HTTPException) else repr(e)
                shutil.move(p, os.path.join(INBOX, "failed", fn))
                from app import notify
                notify.to_admin(f"Файл протокола {fn} не обработан: {detail}. Нужна ручная обработка.", None, "admin_task")
                print("[inbox] ошибка:", fn, detail, flush=True)
        time.sleep(3)


# ------------------------------ API ------------------------------
@app.get("/health")
def health():
    """FIX: проверка для HEALTHCHECK — сервис жив И словарь/матрица загружены и согласованы."""
    try:
        f, r = config.findings(), config.routes()
        missing = {x["route"] for x in f["findings"].values()} - set(r["routes"])
        if missing:
            raise ValueError(f"маршрутов нет в routes.yaml: {missing}")
        store.q("SELECT 1")
    except Exception as e:
        raise HTTPException(503, f"не готов: {e}")
    return {"ok": True, "dictionary": f.get("version"), "matrix": r.get("version")}


@app.get("/")   # адрес API /: GET — получить данные
def index():    # страница статична; все данные она берёт из API с токеном
    """Интерфейс администратора."""
    return FileResponse(os.path.join(STATIC, "index.html")) # отдаём HTML-страницу


@app.post("/api/events", dependencies=[Depends(mis_auth)])
def events(ev: Event):
    """Вебхук для МИС. Повторная доставка того же event_id не создаёт дублей.
    FIX: любая ошибка данных -> 400 и откат (событие можно прислать снова). Было: ловили только KeyError,
    а TypeError/ValueError давали 500 уже после отметки event_id — событие терялось навсегда."""
    try:
        return routing.handle_event(ev.model_dump())
    except ValueError as e:                                 # BadEvent — подкласс ValueError
        raise HTTPException(400, str(e))


@app.post("/api/upload", dependencies=[Depends(admin_auth)])
async def upload(file: UploadFile = File(...), patient_id: str = Form(...), study_type: str = Form(None)):
    """Загрузить файл протокола вручную. FIX: patient_id обязателен (раньше брался из имени файла)."""
    data = await file.read(MAX_UPLOAD + 1)
    if len(data) > MAX_UPLOAD:
        raise HTTPException(413, "Файл больше 10 МБ")
    try:
        return _ingest_file(file.filename or "upload.txt", data, patient_id, study_type)
    except (ValueError, UnicodeDecodeError) as e:
        raise HTTPException(400, str(e))


@app.post("/api/analyze", dependencies=[Depends(admin_auth)])   # адрес API /api/analyze: POST — выполнить действие
def analyze(t: TextIn):
    """Песочница: что найдёт система и почему (ничего не сохраняет)."""
    return extract(t.text, get_ml_hook()).to_dict()        # результат извлечения


@app.get("/api/routes", dependencies=[Depends(admin_auth)])   # адрес API /api/routes: GET — получить данные
def list_routes(status: str = None):
    """Очередь маршрутов: экстренные и требующие верификации — сверху."""
    rows = store.q("SELECT r.*, p.study, p.study_date FROM routes r JOIN protocols p ON p.id=r.protocol_id ORDER BY r.id DESC")   # все маршруты
    order = {"escalated": 0, "pending_verification": 1}    # что показывать первым
    out = []                                                # результат
    for r in rows:                                          # каждый маршрут
        if status and r["status"] != status:                # фильтр по статусу
            continue                                        # пропускаем
        r["findings"] = json.loads(r["findings"])           # находки из JSON
        r["status_label"] = routing.STATUS.get(r["status"], r["status"])   # подпись статуса
        r["specialist"] = config.routes()["routes"].get(r["route_key"], {}).get("specialist", r["route_key"])   # специалист
        out.append(r)                                       # добавляем
    return sorted(out, key=lambda r: (order.get(r["status"], 2), r["priority"], -r["id"]))   # сортировка очереди


@app.get("/api/routes/{rid}", dependencies=[Depends(admin_auth)])   # адрес API /api/routes/{rid}: GET — получить данные
def get_route(rid: int):
    """Карточка маршрута: всё для решения админа и объяснения «почему так сработала система»."""
    r = store.route(rid)                                    # маршрут
    if not r:                                               # нет такого
        raise HTTPException(404, "Маршрут не найден")       # 404
    p = store.q("SELECT * FROM protocols WHERE id=?", (r["protocol_id"],))[0]   # протокол
    p["extraction"] = json.loads(p["extraction"])           # результат извлечения
    rc = config.routes()["routes"].get(r["route_key"], {})  # настройки маршрута
    r["status_label"] = routing.STATUS.get(r["status"], r["status"])   # подпись статуса
    return {
        "route": r, "route_cfg": rc, "protocol": p,         # маршрут, его настройки, протокол
        "audit": store.q("SELECT * FROM audit WHERE route_id=? OR (protocol_id=? AND route_id IS NULL) ORDER BY id", (rid, r["protocol_id"])),   # журнал
        "notifications": store.q("SELECT * FROM notifications WHERE route_id=? ORDER BY id", (rid,)),   # сообщения
        "slots": schedule_mock.slots(r["route_key"]),       # ближайшие слоты (заглушка расписания)
        "open_routes_banner": routing.open_routes(r["patient"]),   # баннер для МИС
    }


@app.post("/api/routes/{rid}/action", dependencies=[Depends(admin_auth)])   # адрес API /api/routes/{rid}/action: POST — выполнить действие
def route_action(rid: int, a: Action):
    """Действие по маршруту (кнопки админа и «телефона пациента»).
    FIX: actor больше не берётся из тела запроса как есть — иначе журнал аудита можно подделать.
    В бою кто нажал = владелец токена; «patient» допустим только в демо (эмулятор телефона)."""
    actor = a.actor if (DEMO and a.actor in ("admin", "patient")) else "admin"
    try:
        return routing.transition(rid, a.action, actor, a.slot, a.comment)
    except ValueError as e:                                 # неизвестное действие / нет маршрута
        raise HTTPException(400, str(e))                    # ошибка 400


@app.get("/api/notifications", dependencies=[Depends(admin_auth)])   # адрес API /api/notifications: GET — получить данные
def notifications(kind: str = None, limit: int = 50):
    limit = max(1, min(limit, 500))                         # FIX: без верхней границы limit=10**9 выгружал всю таблицу
    """Лента «отправленных» сообщений (заглушка): kind=admin | patient."""
    sql = "SELECT * FROM notifications" + (" WHERE kind=?" if kind else "") + " ORDER BY id DESC LIMIT ?"   # запрос
    return store.q(sql, ((kind, limit) if kind else (limit,)))   # результат


@app.get("/api/dashboard", dependencies=[Depends(admin_auth)])   # адрес API /api/dashboard: GET — получить данные
def dashboard():
    """Воронка и экономика."""
    return analytics.dashboard()                            # считаем


@app.get("/api/audit", dependencies=[Depends(admin_auth)])   # адрес API /api/audit: GET — получить данные
def audit(limit: int = 200):
    limit = max(1, min(limit, 1000))
    """Журнал действий."""
    return store.q("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (limit,))   # последние записи


@app.get("/api/clock", dependencies=[Depends(admin_auth)])   # адрес API /api/clock: GET — получить данные
def clock():
    """Текущее модельное время."""
    return {"now": store.ts()}                              # время


@app.post("/api/clock/advance", dependencies=[Depends(admin_auth), Depends(demo_only)])   # адрес API /api/clock/advance: POST — выполнить действие
def clock_advance(hours: float = 24):
    """Промотать модельное время и выполнить созревшие напоминания (только демо)."""
    if not 0 < hours <= 24 * 60:
        raise HTTPException(400, "hours: от 0 до 1440")
    store.advance(hours)                                    # двигаем часы
    return {"now": store.ts(), **routing.tick()}            # и запускаем планировщик


@app.get("/api/patients/{patient}/open_routes", dependencies=[Depends(admin_auth)])   # адрес API /api/patients/{patient}/open_routes: GET — получить данные
def patient_open_routes(patient: str):
    """Для МИС: незавершённые маршруты пациента (баннер при любом визите). patient — псевдо-ID."""
    return routing.open_routes(patient)                     # список баннеров


@app.post("/api/feedback/missed", dependencies=[Depends(admin_auth)])   # адрес API /api/feedback/missed: POST — выполнить действие
def feedback_missed(m: Missed):
    """Админ отметил пропущенную находку — это материал для словаря и дообучения."""
    store.x("INSERT INTO feedback (ts, protocol_id, finding_id, kind, quote, comment) VALUES (?,?,?,?,?,?)",
            (store.ts(), m.protocol_id, m.finding_id, "missed", m.quote, m.comment))   # сохраняем
    store.audit("admin", "feedback_missed", protocol_id=m.protocol_id, finding=m.finding_id)   # журнал
    return {"ok": True}                                     # ответ


@app.get("/api/feedback/export", response_class=PlainTextResponse, dependencies=[Depends(admin_auth)])   # адрес API /api/feedback/export: GET — получить данные
def feedback_export():
    """Выгрузка обратной связи в JSONL (для scripts/train.py и пополнения словаря)."""
    return "\n".join(json.dumps(r, ensure_ascii=False) for r in store.q("SELECT * FROM feedback"))   # построчно JSON


@app.get("/api/config", dependencies=[Depends(admin_auth)])   # адрес API /api/config: GET — получить данные
def get_config():
    """Текущие словарь и матрица (только просмотр; редактируются YAML-файлы)."""
    return {"findings": config.findings(), "routes": config.routes()}   # настройки


@app.post("/api/demo/reset", dependencies=[Depends(admin_auth), Depends(demo_only)])   # FIX: раньше любой мог стереть БД одним POST; адрес API /api/demo/reset: POST — выполнить действие
def demo_reset():
    """Очистить базу (демо)."""
    store.reset()                                           # удаляем и создаём заново
    return {"ok": True}                                     # ответ


@app.post("/api/demo/load", dependencies=[Depends(admin_auth), Depends(demo_only)])   # адрес API /api/demo/load: POST — выполнить действие
def demo_load():
    """Загрузить синтетические протоколы как события МИС (демо)."""
    path = os.path.join(BASE_DIR, "data", "synthetic", "protocols.jsonl")   # файл с синтетикой
    n = 0                                                   # счётчик
    with open(path, encoding="utf-8") as f:                 # читаем
        for line in f:                                      # построчно
            if not line.strip():                            # пустые строки пропускаем
                continue                                    # дальше
            d = json.loads(line)                            # запись
            routing.handle_event({"event_id": f"demo-{d['id']}", "type": "protocol.signed", "protocol_id": d["id"],
                                  "patient_id": d.get("patient_id", d["id"]), "study_type": d.get("study", "УЗИ"),
                                  "text": d["text"]})       # как событие от МИС
            n += 1                                          # считаем
    return {"loaded": n}                                    # ответ
