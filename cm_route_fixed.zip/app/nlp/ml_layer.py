"""ВТОРОЙ СЛОЙ (необязательный): обученная локальная модель — «страховочная сеть».

Правила из словаря дают точность и объяснимость. Но врачи пишут непредсказуемо, и часть
формулировок правила пропустят (ложноотрицательные). Модель, обученная на размеченных
предложениях, может заметить такие места и показать их админу с пометкой «проверить».
Модель НИКОГДА не отменяет решение правил и не принимает решение о маршруте.

Сейчас здесь два варианта:
  1. SentenceClassifier — лёгкая модель (TF-IDF по буквосочетаниям + логистическая регрессия).
     Обучается за секунды скриптом scripts/train.py, работает на любом сервере без GPU.
  2. LocalLLMExtractor — ЗАГОТОВКА под локальную LLM внутри контура клиники (Ollama / llama.cpp).
     Не реализована: подключать, когда будет сервер клиники и согласование с ИБ.
"""
import os                                      # проверка существования файла модели
from app import config                         # настройки (включена ли модель, порог)
from app.config import BASE_DIR                # корень проекта


class SentenceClassifier:
    """Обёртка над обученной моделью: предложение -> [(находка, вероятность)]."""
    name = "sentence_clf"                       # имя модели — пишется в правило срабатывания

    def __init__(self, path: str, threshold: float):
        import joblib                           # загрузка сохранённой модели (идёт вместе со scikit-learn)
        bundle = joblib.load(path)              # читаем файл модели с диска (локально)
        self.model = bundle["model"]            # сам классификатор
        self.labels = bundle["labels"]          # список находок, которым модель обучена
        self.version = bundle.get("version", "?")   # версия модели
        self.threshold = threshold              # порог вероятности

    def predict(self, sentence: str):
        """Вернуть находки, вероятность которых выше порога."""
        probs = self.model.predict_proba([sentence])[0]   # вероятности всех классов для предложения
        return [(lab, float(p)) for lab, p in zip(self.labels, probs) if lab != "none" and p >= self.threshold]   # только уверенные и не «нет находки»


class LocalLLMExtractor:
    """ЗАГОТОВКА. Локальная LLM в контуре клиники (данные не покидают сервер).

    Как подключить (план):
      1. На сервере клиники поднять Ollama или llama.cpp с моделью, которая понимает русский
         (например, семейства Qwen / Llama, 7–8B параметров, квантованная — хватит одной GPU 16 ГБ).
      2. Здесь отправлять предложение на http://localhost:11434 с промптом
         «верни JSON: какие находки из списка {labels} описаны, с цитатой».
      3. Ответ проверять: цитата должна дословно быть в тексте, иначе — игнорировать (защита от выдумок).
      4. Как и SentenceClassifier — только как «на проверку», не как окончательное решение.
    """
    name = "local_llm"                          # имя для журнала

    def predict(self, sentence: str):
        raise NotImplementedError("Локальная LLM не подключена — см. docstring класса")   # явно сообщаем, что это заглушка


_cached = {"key": None, "obj": None}            # кэш загруженной модели


def get_ml_hook():
    """Вернуть модель, если она включена в findings.yaml и файл существует. Иначе None."""
    ml = config.findings().get("ml", {})       # раздел ml из словаря
    if not ml.get("enabled"):                   # выключено
        return None                             # работаем только на правилах
    path = os.path.join(BASE_DIR, ml.get("model_path", "models/sentence_clf.joblib"))   # путь к файлу модели
    if not os.path.exists(path):                # модель ещё не обучена
        return None                             # тихо работаем без неё
    key = (path, os.path.getmtime(path), ml.get("threshold", 0.7))   # ключ кэша: файл + время + порог
    if _cached["key"] != key:                   # модель новая или переобучена
        _cached.update(key=key, obj=SentenceClassifier(path, ml.get("threshold", 0.7)))   # загружаем заново
    return _cached["obj"]                       # готовая модель
