"""ИЗВЛЕЧЕНИЕ НАХОДОК из текста протокола. Полностью локально, без внешних LLM.

Как это работает (по шагам, для каждого протокола):
  1. Текст режем на слова и приводим слова к начальной форме (normalize.py).
  2. Предложения с рекомендациями врача УЗИ («рекомендована консультация гинеколога»)
     не считаем описанием находки, но запоминаем, какого специалиста рекомендовали.
  3. Для каждой находки из словаря ищем:
       а) самодостаточные термины («холецистолитиаз»);
       б) пары «ЧТО + ГДЕ» («полип» + ближайший орган = «эндометрий»).
  4. Каждого кандидата проверяем: отрицание («не выявлено»), анамнез («удалён»),
     исключения («фолликулярная»), числовые условия (размер, BI-RADS), неуверенность.
  5. Возвращаем: принятые находки (с цитатой, правилом, атрибутами, уверенностью)
     и отклонённые кандидаты (с причиной — это объяснение «почему не сработало»).

Решение о маршруте здесь НЕ принимается — это делает routing.py по матрице.
"""
import re                                            # регулярные выражения для размеров и BI-RADS
from dataclasses import dataclass, field, asdict     # структуры результата
from app import config                               # доступ к YAML-настройкам
from app.nlp.normalize import tokenize, phrase_lemmas, similar, norm_text   # нормализация текста

# Размер: «12 мм», «1,5 см», «12х8х10 мм» (берём максимальное измерение)
SIZE_RE = re.compile(r"(\d+(?:[.,]\d+)?(?:\s*[xх×*]\s*\d+(?:[.,]\d+)?)*)\s*(мм|см)(?![а-я])")
# BI-RADS: «BI-RADS 4», «BIRADS: 3», «би-рэдс 5»
BIRADS_RE = re.compile(r"(?:bi\s*-?\s*rads|birads|би\s*-?\s*рэдс)\s*[:\-]?\s*(?:категория\s*)?([0-6])")


@dataclass
class Evidence:
    """Доказательство одного срабатывания — то, что видит врач/админ."""
    quote: str             # найденный фрагмент текста
    sentence: str          # всё предложение целиком (контекст)
    start: int             # позиция начала фрагмента в тексте (для подсветки)
    end: int               # позиция конца фрагмента
    rule: str              # какое правило словаря сработало
    attributes: dict       # извлечённые атрибуты (размер, BI-RADS)
    confidence: float      # уверенность 0..1
    flags: list            # пометки: «неуверенная формулировка», «нет размера — проверить» и т.п.


@dataclass
class Finding:
    """Принятая находка (может иметь несколько доказательств в тексте)."""
    id: str                # ключ находки из словаря
    name: str              # человекочитаемое название
    route: str             # ключ маршрута из routes.yaml
    priority: int          # приоритет 1..3
    urgent: bool           # экстренная ли
    confidence: float      # итоговая уверенность (максимум по доказательствам)
    needs_review: bool     # требуется ли особое внимание админа
    evidence: list = field(default_factory=list)   # список Evidence


@dataclass
class Suppressed:
    """Кандидат, который НЕ стал находкой, и почему (объяснимость для нормы)."""
    id: str                # ключ находки
    name: str              # название
    quote: str             # фрагмент текста
    reason: str            # причина отказа


@dataclass
class ExtractionResult:
    """Всё, что извлекли из одного протокола."""
    findings: list                 # принятые находки
    suppressed: list               # отклонённые кандидаты с причинами
    clinician_recommended: list    # ключи маршрутов, которые рекомендовал сам врач УЗИ
    normal_quotes: list            # найденные фразы нормы («без патологии»)
    dictionary_version: str        # версия словаря
    summary: str                   # короткое объяснение итога одной строкой
    suppressed_in_recommendation: bool = False   # FIX: была находка внутри рекомендации — сигнал админу

    def to_dict(self):
        """Превратить в обычный словарь (для JSON-ответа API и хранения)."""
        return asdict(self)        # dataclass -> dict рекурсивно


# ----------------------------------------------------------------------------------
# Подготовка словаря: фразы из YAML превращаем в списки лемм один раз и кэшируем
# ----------------------------------------------------------------------------------
_compiled = {"src": None, "data": None}   # кэш: исходный словарь -> скомпилированный


def _compile(fcfg: dict, rcfg: dict) -> dict:
    """Перевести словарь из YAML во внутренний вид (леммы). Пересобирается при изменении YAML."""
    if _compiled["src"] is fcfg and _compiled.get("rsrc") is rcfg:   # словарь не менялся — отдаём кэш
        return _compiled["data"]                                    # уже скомпилировано
    mods = fcfg.get("modifiers", {})                                # общие модификаторы
    data = {
        "matching": fcfg.get("matching", {}),                       # параметры поиска
        "locations": {k: [phrase_lemmas(p) for p in v] for k, v in fcfg.get("locations", {}).items()},   # органы
        "mods": {k: [phrase_lemmas(p, drop_stop=False) for p in v] for k, v in mods.items() if k != "scope_breakers"},  # модификаторы
        "breakers": set(mods.get("scope_breakers", [])),            # слова-разрыватели области отрицания
        "findings": {},                                             # находки
        "aliases": {rid: [phrase_lemmas(a) for a in r.get("aliases", [])] for rid, r in rcfg.get("routes", {}).items()},  # специалисты в рекомендациях
    }
    for fid, f in fcfg.get("findings", {}).items():                 # каждая находка словаря
        data["findings"][fid] = {
            **f,                                                    # все поля как есть (name, route, condition...)
            "terms_l": [(t, phrase_lemmas(t)) for t in f.get("terms", [])],     # самодостаточные термины
            "what_l": [(t, phrase_lemmas(t)) for t in f.get("what", [])],       # «что»
            "exclude_l": [(t, phrase_lemmas(t)) for t in f.get("exclude", [])], # исключения
        }
    _compiled.update(src=fcfg, rsrc=rcfg, data=data)                # сохраняем в кэш
    return data                                                     # скомпилированный словарь


# ----------------------------------------------------------------------------------
# Поиск фразы в последовательности слов
# ----------------------------------------------------------------------------------
def _tok_sim(tok, variants, thr):
    """Похожесть слова текста на слово словаря (variants — все формы слова словаря).
    1) есть общая начальная форма -> точное совпадение; 2) иначе ищем опечатку."""
    if tok.alts & variants or tok.raw in variants:          # общая начальная форма («железы» и «железа»)
        return 1.0                                          # точное совпадение
    return max(max(similar(tok.lemma, v, thr), similar(tok.raw, v, thr)) for v in variants)   # лучшая похожесть с учётом опечаток


def _match(tokens, plem, thr, max_gap):
    """Найти все вхождения фразы plem (список лемм). Вернуть [(индекс_начала, индекс_конца, оценка)]."""
    out = []                                                        # найденные вхождения
    n = len(tokens)                                                 # число слов
    if not plem:                                                    # пустая фраза — нечего искать
        return out                                                  # ничего не нашли
    for i in range(n):                                              # пробуем начать с каждого слова
        score = _tok_sim(tokens[i], plem[0], thr)                   # совпадает ли первое слово фразы
        if not score:                                               # не совпало
            continue                                                # следующее слово
        j, ok = i, True                                             # j — позиция последнего совпавшего слова
        for p in plem[1:]:                                          # остальные слова фразы
            hit = None                                              # совпадение для текущего слова фразы
            for k in range(j + 1, min(j + 2 + max_gap, n)):         # смотрим вперёд с допуском «лишних» слов
                if tokens[k].sent != tokens[i].sent:                # фраза не может перескочить в другое предложение
                    break                                           # прекращаем поиск
                s = _tok_sim(tokens[k], p, thr)                     # похожесть
                if s:                                               # нашли
                    hit = (k, s)                                    # запоминаем позицию и оценку
                    break                                           # дальше не ищем
            if not hit:                                             # слово фразы не нашлось
                ok = False                                          # фраза не совпала
                break                                               # выходим
            j, score = hit[0], min(score, hit[1])                   # сдвигаемся; итоговая оценка — по худшему слову
        if ok:                                                      # вся фраза совпала
            out.append((i, j, score))                               # сохраняем вхождение
    return out                                                      # все вхождения


def _any_near(tokens, phrases, lo, hi, thr, same_sent, same_clause=None, breakers=frozenset()):
    """Есть ли одна из фраз в окне слов [lo, hi]. Возвращает найденную фразу (текстом) или None."""
    lo, hi = max(lo, 0), min(hi, len(tokens) - 1)                   # обрезаем окно по границам текста
    window = [t for t in tokens[lo : hi + 1] if t.sent == same_sent and (same_clause is None or t.clause == same_clause)]  # слова окна в нужном предложении/части
    if not window:                                                  # окно пустое
        return None                                                 # ничего нет
    for plem in phrases:                                            # каждая фраза-модификатор
        for i, j, _ in _match(window, plem, thr, 0):                # ищем её в окне (без пропусков слов)
            return " ".join(t.raw for t in window[i : j + 1])       # нашли — возвращаем текст
    return None                                                     # не нашли


def _has_breaker(tokens, a, b, breakers):
    """Есть ли между словами a и b слово-разрыватель («но», «однако»)."""
    return any(t.raw in breakers for t in tokens[min(a, b) + 1 : max(a, b)])   # проверяем промежуток


def _sizes(low, a, b):
    """Все размеры в диапазоне символов [a, b): [(позиция, размер_в_мм)]."""
    res = []                                                        # результат
    for m in SIZE_RE.finditer(low, a, b):                           # ищем размеры в диапазоне
        nums = [float(x.replace(",", ".")) for x in re.findall(r"\d+(?:[.,]\d+)?", m.group(1))]   # все измерения
        mm = max(nums) * (10 if m.group(2) == "см" else 1)          # максимальное, сантиметры -> миллиметры
        res.append((m.start(), round(mm, 1)))                       # сохраняем позицию и размер
    return res                                                      # список размеров


# ----------------------------------------------------------------------------------
# Главная функция
# ----------------------------------------------------------------------------------
def extract(text: str, ml_hook=None) -> ExtractionResult:
    """Найти находки в тексте протокола. ml_hook — необязательная обученная модель (второй слой)."""
    fcfg, rcfg = config.findings(), config.routes()                 # актуальные настройки
    D = _compile(fcfg, rcfg)                                        # скомпилированный словарь
    M = D["matching"]                                               # параметры поиска
    thr = M.get("fuzzy_threshold", 85)                              # порог опечаток
    gap = M.get("max_gap", 1)                                       # допуск лишних слов
    nwin = M.get("negation_window", 4)                              # окно отрицания
    mwin = M.get("modifier_window", 5)                              # окно модификаторов
    low = norm_text(text)                                           # нормализованный текст (та же длина)
    tokens = tokenize(text)                                         # слова
    if not tokens:                                                  # пустой протокол
        return ExtractionResult([], [], [], [], fcfg.get("version", "?"), "Пустой текст")   # нечего анализировать

    sents = {}                                                      # номер предложения -> его слова
    for t in tokens:                                                # раскладываем слова по предложениям
        sents.setdefault(t.sent, []).append(t)                      # добавляем слово в своё предложение

    def sent_text(sid):                                             # исходный текст предложения
        ts = sents[sid]                                             # слова предложения
        return text[ts[0].start : ts[-1].end]                       # от первого до последнего символа

    # --- Шаг 2. Предложения-рекомендации и рекомендованные специалисты
    # FIX: исключаем не всё предложение, а только часть ОТ слова «рекомендовано» до конца предложения.
    # Было: «Полип эндометрия 12 мм, рекомендована консультация гинеколога» терялось целиком,
    # а «…полип ЖП 12 мм, рекомендовано наблюдение» — молча, без единого пуша.
    rec_from = {}                                                   # предложение -> индекс первого слова рекомендации
    for sid, ts in sents.items():
        for p in D["mods"].get("recommendation_markers", []):
            for i, _, _ in _match(ts, p, thr, 0):
                rec_from[sid] = min(rec_from.get(sid, 10**9), ts[i].idx)
    rec_sents = set(rec_from)                                       # для второго слоя (модель)

    def in_recommendation(tok_idx):
        t = tokens[tok_idx]
        return t.sent in rec_from and t.idx >= rec_from[t.sent]

    recommended = []
    for rid, aliases in D["aliases"].items():
        for sid, start in rec_from.items():
            part = [t for t in sents[sid] if t.idx >= start]        # только сама рекомендация
            if any(_match(part, a, thr, gap) for a in aliases):
                recommended.append(rid)
                break

    # --- Упоминания органов (для правил «ЧТО + ГДЕ»)
    loc_mentions = []                                               # [(орган, начало, конец)]
    for loc, variants in D["locations"].items():                    # каждый орган
        for plem in variants:                                       # каждый вариант названия
            for i, j, _ in _match(tokens, plem, thr, gap):          # все вхождения
                loc_mentions.append((loc, i, j))                    # сохраняем

    # FIX: орган из заголовка раздела. Протоколы УЗИ пишутся блоками
    # «Желчный пузырь: размеры… .\nВ просвете полип 12 мм.» — во втором предложении органа нет,
    # и находка терялась. Запоминаем орган, с которого начинается строка/предложение (первые 3 слова).
    section_of = {}                                                 # номер предложения -> (орган, a, b) раздела
    cur = None
    starts = {}
    for loc, a, b in loc_mentions:
        if tokens[a].idx - sents[tokens[a].sent][0].idx < 3:        # орган в начале предложения
            starts.setdefault(tokens[a].sent, (loc, a, b))
    for sid in sorted(sents):
        line_start = sents[sid][0].start == 0 or "\n" in text[max(0, sents[sid][0].start - 3):sents[sid][0].start]
        if sid in starts:
            cur = starts[sid]
        elif line_start and sid > 0 and "\n\n" in text[sents[sid - 1][-1].end:sents[sid][0].start]:
            cur = None                                              # пустая строка — раздел закончился
        section_of[sid] = cur

    def nearest_location(i, j):
        """Ближайший орган к словам [i, j] в том же предложении. Своя часть предложения важнее."""
        best, best_d = None, 10**9                                  # лучший кандидат и его «расстояние»
        for loc, a, b in loc_mentions:                              # все упоминания органов
            if tokens[a].sent != tokens[i].sent:                    # другой предложение — не подходит
                continue                                            # пропускаем
            d = min(abs(a - j), abs(i - b))                         # расстояние в словах
            if tokens[a].clause != tokens[i].clause:                # орган в другой части предложения (за запятой)
                d += 10                                             # штраф: свой фрагмент приоритетнее
            if d < best_d:                                          # нашли ближе
                best, best_d = (loc, a, b), d                       # запоминаем
        if best is None and section_of.get(tokens[i].sent):         # в предложении органа нет — берём орган раздела
            return section_of[tokens[i].sent] + (True,)
        return best + (False,) if best else None                    # (орган, начало, конец, из_заголовка)

    heads = [plem[0] for f in D["findings"].values() for _, plem in f["terms_l"] + f["what_l"] if plem]   # первые слова всех находок

    def list_negation(anchor):
        """Отрицание, «наследуемое» через перечисление: «Без признаков полипа, гиперплазии» —
        «гиперплазии» стоит в начале следующей части и продолжает отрицательный список.
        Но «Эндометрий без особенностей, полип 7 мм» — НЕ список находок, отрицание не наследуется."""
        k = anchor                                                  # идём назад по частям предложения
        while True:                                                 # пока продолжается перечисление
            ta = tokens[k]                                          # текущее слово-начало
            if k == 0 or tokens[k - 1].clause == ta.clause or tokens[k - 1].sent != ta.sent:   # не начало части или начало предложения
                return None                                         # перечисления нет
            prev = [t for t in tokens if t.sent == ta.sent and t.clause == ta.clause - 1]   # предыдущая часть предложения
            if not prev:                                            # её нет
                return None                                         # перечисления нет
            for plem in D["mods"].get("negation_before", []):       # ищем отрицание в предыдущей части
                for ci, cj, _ in _match(prev, plem, thr, 0):        # нашли отрицание
                    if any(_tok_sim(t, h, thr) for t in prev[cj + 1 :] for h in heads):   # и после него идёт находка
                        return " ".join(t.raw for t in prev[ci : cj + 1])   # значит, это отрицательное перечисление
            if not any(_tok_sim(prev[0], h, thr) for h in heads):   # предыдущая часть тоже не начинается с находки
                return None                                         # перечисление закончилось
            k = prev[0].idx                                         # шагаем ещё на часть назад

    def negation_after(j):
        """FIX: отрицание после находки — только в своей части предложения или через перечисление находок.
        Было: окно 4 слова поверх запятых, и «Полип ЖП 12 мм, васкуляризации нет» отклонялся как «отрицание».
        Перечисление сохраняем: «Конкрементов, полипов не выявлено»."""
        tj = tokens[j]
        own = [t for t in sents[tj.sent] if t.clause == tj.clause and t.idx > j][:nwin]
        for plem in D["mods"].get("negation_after", []):
            for a, b, _ in _match(own, plem, thr, 0):
                if not _has_breaker(tokens, j, own[b].idx, D["breakers"]):
                    return " ".join(t.raw for t in own[a:b + 1])
        c = tj.clause + 1
        while True:                                                 # следующие части: продолжаем, только пока это перечисление находок
            part = [t for t in sents[tj.sent] if t.clause == c]
            if not part or any(t.raw in D["breakers"] for t in part):
                return None
            for plem in D["mods"].get("negation_after", []):
                for a, b, _ in _match(part, plem, thr, 0):
                    if a == 0 or any(_tok_sim(part[0], h, thr) for h in heads):   # «…, не выявлено» / «…, полипов не выявлено»
                        return " ".join(t.raw for t in part[a:b + 1])
            if not any(_tok_sim(part[0], h, thr) for h in heads):
                return None
            c += 1

    accepted, suppressed = {}, []                                   # итоговые находки и отклонённые кандидаты
    in_rec_flag = [False]
    seen_spans = set()                                              # чтобы одно место текста не засчитать дважды

    for fid, f in D["findings"].items():                            # --- Шаг 3. Каждая находка словаря
        cands = []                                                  # кандидаты: (нач, кон, оценка, правило)
        for term, plem in f["terms_l"]:                             # а) самодостаточные термины
            for i, j, s in _match(tokens, plem, thr, gap):          # все вхождения
                cands.append((i, j, s * 0.95, f"{fid}.terms['{term}']", s, i))   # базовая уверенность 0.95; отрицание ищем перед термином
        for what, plem in f["what_l"]:                              # б) «ЧТО + ГДЕ»
            for i, j, s in _match(tokens, plem, thr, gap):          # все вхождения «что»
                loc = nearest_location(i, j)                        # ближайший орган
                if loc and loc[0] in f.get("where", []):            # орган подходит этой находке
                    if loc[3]:                                      # орган из заголовка раздела — фрагмент только «что»
                        cands.append((i, j, s * 0.8, f"{fid}.what['{what}']+section[{loc[0]}]", s, i))
                    else:
                        a, b = min(i, loc[1]), max(j, loc[2])       # общий фрагмент «что + где»
                        cands.append((a, b, s * 0.9, f"{fid}.what['{what}']+where[{loc[0]}]", s, i))

        for i, j, score, rule, raw_s, anchor in sorted(cands, key=lambda c: -c[2]):   # --- Шаг 4. Проверяем кандидатов (сильные первыми)
            if (fid, i, j) in seen_spans or any(fid == s[0] and not (j < s[1] or i > s[2]) for s in seen_spans):  # пересекается с уже принятым
                continue                                            # дубль — пропускаем
            t0, t1 = tokens[i], tokens[j]                           # первое и последнее слово фрагмента
            sid = t0.sent                                           # номер предложения
            quote = text[t0.start : t1.end]                         # фрагмент текста
            flags, conf = [], score                                 # пометки и уверенность
            if raw_s < 1.0:                                         # совпадение нечёткое (опечатка)
                flags.append(f"нечёткое совпадение (возможна опечатка), сходство {raw_s:.2f}")   # пометка для админа

            if in_recommendation(anchor):                           # находка внутри самой рекомендации («рекомендовано исключить полип»)
                suppressed.append(Suppressed(fid, f["name"], quote, "упоминание в рекомендации, а не в описании"))
                in_rec_flag[0] = True
                continue

            # FIX: исключение действует только в своей части предложения. Было ±5 слов через запятую:
            # «Фолликулярная киста справа, слева образование яичника 35 мм» — образование отклонялось.
            ex = None
            for cl_ in {t0.clause, t1.clause, tokens[anchor].clause}:
                ex = ex or _any_near(tokens, [p for _, p in f["exclude_l"]], i - mwin, j + mwin, thr, sid, cl_)
            if ex:                                                  # нашлось исключение
                suppressed.append(Suppressed(fid, f["name"], quote, f"исключение по словарю: «{ex}»"))   # объяснение
                continue                                            # не считаем

            ta = tokens[anchor]                                     # слово, перед которым ищем отрицание («что»)
            neg = _any_near(tokens, D["mods"].get("negation_before", []), anchor - nwin, anchor - 1, thr, sid, ta.clause)   # отрицание перед (в той же части предложения)
            if not neg:                                             # перед нет — может, это продолжение отрицательного перечисления
                neg = list_negation(anchor)                         # «Без полипа, гиперплазии...»
            if not neg:                                             # перед нет — смотрим после
                neg = negation_after(j)
            unc = _any_near(tokens, D["mods"].get("uncertainty", []), i - mwin, j + mwin, thr, sid)   # неуверенность («не исключён»)
            if neg and not (unc and "исключ" in unc):               # отрицание есть и это не «не исключён»
                suppressed.append(Suppressed(fid, f["name"], quote, f"отрицание: «{neg}»"))   # объяснение для нормы
                continue                                            # не считаем

            # FIX: анамнез — только в своей части предложения или в начале следующей («Полип, удалён в 2022»);
            # слова «вновь / рецидив / повторно» анамнез отменяют. Было ±5 слов поверх запятых:
            # «Состояние после полипэктомии, в полости матки вновь полип 10 мм» отклонялось.
            hist = None
            for cl_ in {t0.clause, t1.clause, tokens[anchor].clause}:
                hist = hist or _any_near(tokens, D["mods"].get("history", []), i - mwin, j + mwin, thr, sid, cl_)
            nxt = [t for t in sents[sid] if t.clause == t1.clause + 1][:3]
            if not hist and nxt:
                hist = _any_near(nxt, D["mods"].get("history", []), 0, len(nxt) - 1, thr, sid)
            if hist and _any_near(tokens, D["mods"].get("recurrence", []), i - mwin, j + mwin, thr, sid):
                hist = None
            if hist:                                                # находка в прошлом
                suppressed.append(Suppressed(fid, f["name"], quote, f"упоминание в анамнезе: «{hist}»"))   # объяснение
                continue                                            # не считаем

            if unc:                                                 # формулировка неуверенная
                flags.append(f"неуверенная формулировка: «{unc}»")   # пометка для админа
                conf *= 0.75                                        # снижаем уверенность, но находку оставляем

            # --- атрибуты: размер (ближайший после фрагмента в предложении) и BI-RADS
            s_lo, s_hi = sents[sid][0].start, sents[sid][-1].end    # границы предложения в символах
            cl = [t for t in sents[sid] if t.clause in (t0.clause, t1.clause)]   # слова той же части предложения
            sizes = _sizes(low, cl[0].start, cl[-1].end + 3)        # сначала ищем размер в своей части (между запятыми)
            if not sizes and "size_mm_min" in (f.get("condition") or {}):   # не нашли, а размер важен для условия
                sizes = [x for x in _sizes(low, s_lo, s_hi + 3) if x[0] >= t1.end]   # тогда — дальше по предложению
            after = [mm for pos, mm in sizes if pos >= t0.start]    # размеры после начала фрагмента
            attrs = {}                                              # извлечённые атрибуты
            if after or sizes:                                      # размер найден
                attrs["size_mm"] = after[0] if after else sizes[-1][1]   # ближайший после, иначе последний перед
            # FIX: BI-RADS из всего текста брался ПЕРВЫЙ попавшийся — правая железа BI-RADS 2 «закрывала»
            # образование левой. Теперь: своё предложение (максимум, если несколько); из всего текста —
            # только если категория в протоколе одна (типично «Заключение: BI-RADS 4»). Иначе — «проверить».
            in_sent = [int(m.group(1)) for m in BIRADS_RE.finditer(low, s_lo, s_hi + 3)]
            in_text = set()                                         # категории из «самостоятельных» предложений (заключение)
            for m in BIRADS_RE.finditer(low):
                ms = next((t.sent for t in tokens if t.start >= m.start()), None)
                if ms is None or ms == sid:
                    continue
                if any(_tok_sim(t, h, thr) for t in sents[ms] if t.raw not in ("bi", "rads", "би", "рэдс") for h in heads):
                    in_text.add(-1)                                 # категория относится к другой находке/стороне — не наша
                else:
                    in_text.add(int(m.group(1)))
            if in_sent:
                attrs["birads"] = max(in_sent)
            elif len(in_text) == 1 and -1 not in in_text:
                attrs["birads"] = in_text.pop()
            elif in_text:
                flags.append("в протоколе несколько категорий BI-RADS, сторона не определена — проверить")

            cond = f.get("condition") or {}                         # числовые условия находки
            failed, missing = None, []                              # причина провала и недостающие атрибуты
            if "size_mm_min" in cond:                               # условие по размеру
                if "size_mm" not in attrs:                          # размера нет в тексте
                    missing.append("размер")                        # запоминаем
                elif attrs["size_mm"] < cond["size_mm_min"]:        # размер меньше порога
                    failed = f"размер {attrs['size_mm']} мм < {cond['size_mm_min']} мм"   # причина
            if "birads_min" in cond:                                # условие по BI-RADS
                if "birads" not in attrs:                           # категории нет
                    missing.append("BI-RADS")                       # запоминаем
                elif attrs["birads"] < cond["birads_min"]:          # категория ниже порога
                    failed = f"BI-RADS {attrs['birads']} < {cond['birads_min']}"   # причина
            if failed:                                              # условие не выполнено
                suppressed.append(Suppressed(fid, f["name"], quote, f"условие не выполнено: {failed}"))   # объяснение
                continue                                            # не считаем
            if missing:                                             # атрибута нет в тексте
                if f.get("on_missing_attribute", "review") == "skip":   # по настройке — не считать
                    suppressed.append(Suppressed(fid, f["name"], quote, f"нет атрибута: {', '.join(missing)}"))   # объяснение
                    continue                                        # не считаем
                flags.append(f"в тексте нет: {', '.join(missing)} — проверить вручную")   # иначе — показать с пометкой
                conf *= 0.7                                         # и снизить уверенность

            ev = Evidence(quote, sent_text(sid), t0.start, t1.end, f"{rule} @словарь v{fcfg.get('version')}", attrs, round(conf, 2), flags)   # доказательство
            fd = accepted.get(fid)                                  # уже есть такая находка?
            if not fd:                                              # первая — создаём
                fd = accepted[fid] = Finding(fid, f["name"], f["route"], f.get("priority", 3), bool(f.get("urgent")), 0.0, False)   # новая находка
            fd.evidence.append(ev)                                  # добавляем доказательство
            fd.confidence = max(fd.confidence, ev.confidence)       # итоговая уверенность — максимум
            fd.needs_review = fd.needs_review or bool(flags)        # есть пометки — нужна проверка
            seen_spans.add((fid, i, j))                             # фрагмент занят

    # --- Второй слой (необязательный): обученная модель ищет то, что пропустили правила
    if ml_hook is not None:                                         # модель подключена
        for sid, ts in sents.items():                               # каждое предложение
            if sid in rec_sents:                                    # рекомендации пропускаем
                continue                                            # дальше
            for fid, prob in ml_hook.predict(sent_text(sid)):       # модель предсказала находку
                f = D["findings"].get(fid)                          # описание находки
                if not f or fid in accepted or any(s.id == fid for s in suppressed):   # уже решено правилами
                    continue                                        # правила важнее модели
                fd = accepted[fid] = Finding(fid, f["name"], f["route"], f.get("priority", 3), bool(f.get("urgent")), round(prob * 0.6, 2), True)   # находка «на проверку»
                fd.evidence.append(Evidence(sent_text(sid), sent_text(sid), ts[0].start, ts[-1].end, f"ml:{ml_hook.name}", {}, round(prob * 0.6, 2), ["найдено моделью, правило не сработало — проверить"]))   # доказательство

    # --- Фразы нормы (для объяснения)
    normal_quotes = []                                              # найденные «без патологии»
    for plem in D["mods"].get("normal_phrases", []):                # каждая фраза нормы
        for i, j, _ in _match(tokens, plem, thr, 0):                # вхождения
            normal_quotes.append(text[tokens[i].start : tokens[j].end])   # сохраняем текст

    uniq = {}                                                       # убираем дубли среди отклонённых
    for x in suppressed:                                            # каждый отклонённый кандидат
        if x.id not in accepted:                                    # если находка всё же принята по другому месту — не путаем админа
            uniq.setdefault((x.id, x.reason), x)                    # одна запись на (находка, причина)
    suppressed = list(uniq.values())                                # итоговый список

    found = sorted(accepted.values(), key=lambda x: (not x.urgent, x.priority, -x.confidence))   # сортировка: экстренные, приоритет, уверенность
    if found:                                                       # есть находки
        summary = f"Найдено находок: {len(found)}"                  # короткий итог
    elif suppressed:                                                # кандидаты были, но отклонены
        summary = "Находок нет: кандидаты отклонены (" + "; ".join(sorted({s.reason.split(':')[0] for s in suppressed})) + ")"   # почему
    elif normal_quotes:                                             # явная норма
        summary = "Находок нет: в протоколе описана норма"          # итог
    else:                                                           # ничего из словаря
        summary = "Находок нет: совпадений со словарём не найдено"  # итог
    return ExtractionResult(found, suppressed, recommended, normal_quotes, fcfg.get("version", "?"), summary, in_rec_flag[0])
