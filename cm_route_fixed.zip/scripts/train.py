"""ОБУЧЕНИЕ второго слоя (необязательно). Скелет — чтобы было понятно, как это устроено.

Главное «обучение» этой системы — НЕ нейросеть, а пополнение словаря (config/findings.yaml):
  1) размечаете протоколы (формат — в scripts/evaluate.py);
  2) запускаете evaluate.py -> смотрите reports/errors.csv;
  3) пропуски (FN) -> добавляете синонимы/формулировки; лишние (FP) -> исключения/отрицания;
  4) повторяете, пока FN и FP не станут приемлемыми. Каждое изменение -> новая version в YAML.

Этот скрипт обучает ДОПОЛНИТЕЛЬНУЮ лёгкую модель на предложениях (без GPU, за секунды):
  предложение -> какая находка в нём описана (или "none").
Модель ловит формулировки, которых нет в словаре, и показывает их админу «на проверку».

Запуск:  python scripts/train.py [разметка.jsonl]
Потом в config/findings.yaml: ml.enabled: true
"""
import json                                                    # чтение разметки
import os                                                      # пути
import sys                                                     # аргументы
from collections import Counter                                # статистика классов

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))   # импорт app/ из корня
from app.nlp.normalize import tokenize                         # та же нарезка на предложения, что и в системе

from sklearn.feature_extraction.text import TfidfVectorizer   # признаки: буквосочетания (устойчивы к опечаткам и падежам)
from sklearn.linear_model import LogisticRegression           # простой и объяснимый классификатор
from sklearn.model_selection import cross_val_predict         # честная проверка на отложенных частях
from sklearn.metrics import classification_report             # точность/полнота по классам
from sklearn.pipeline import make_pipeline                    # склейка «признаки + модель»
import joblib                                                  # сохранение модели в файл


def sentences(text):
    """Разбить текст на предложения (с позициями) — так же, как это делает extractor."""
    groups = {}                                                # номер предложения -> слова
    for t in tokenize(text):                                   # слова текста
        groups.setdefault(t.sent, []).append(t)                # группируем
    return [(text[ts[0].start : ts[-1].end]) for ts in groups.values()]   # тексты предложений


def build_dataset(path):
    """Из разметки протоколов сделать пары (предложение, метка)."""
    X, y = [], []                                              # предложения и метки
    for line in open(path, encoding="utf-8"):                  # каждый протокол
        if not line.strip():                                   # пустые строки
            continue                                           # пропускаем
        r = json.loads(line)                                   # запись
        for s in sentences(r["text"]):                         # каждое предложение
            label = "none"                                     # по умолчанию — находки нет
            for e in r["expected"]:                            # размеченные находки
                if e.get("quote") and e["quote"].lower() in s.lower():   # цитата находки в этом предложении
                    label = e["id"]                            # метка = находка
                    break                                      # одной метки достаточно (упрощение)
            X.append(s)                                        # предложение
            y.append(label)                                    # метка
    return X, y                                                # датасет


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "data/synthetic/protocols.jsonl"   # файл разметки
    X, y = build_dataset(path)                                 # датасет
    print("Предложений:", len(X), "| классы:", dict(Counter(y)))   # статистика
    model = make_pipeline(                                     # модель = признаки + классификатор
        TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), lowercase=True, min_df=1),   # буквосочетания 3–5 символов внутри слов
        LogisticRegression(max_iter=2000, class_weight="balanced"),   # балансировка: находок мало, «none» много
    )
    rare = [c for c, n in Counter(y).items() if n < 3]          # классы, где примеров меньше 3
    if rare:                                                   # для кросс-валидации их мало
        print("Мало примеров (нужно ≥3, лучше 20+):", rare)     # предупреждаем
    else:                                                      # хватает — честно проверяем
        pred = cross_val_predict(model, X, y, cv=3)            # предсказания на отложенных частях
        print(classification_report(y, pred, zero_division=0)) # отчёт точность/полнота
    model.fit(X, y)                                            # обучаем на всех данных
    os.makedirs("models", exist_ok=True)                       # папка моделей
    joblib.dump({"model": model, "labels": list(model.classes_), "version": "0.1"}, "models/sentence_clf.joblib")   # сохраняем
    print("Модель сохранена: models/sentence_clf.joblib. Включите ml.enabled в config/findings.yaml")   # что дальше


if __name__ == "__main__":                                     # запуск как скрипта
    main()                                                     # поехали
